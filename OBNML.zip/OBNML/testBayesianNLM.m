clc;
clear all;

%% 
% Input Image Data
% path ='D:\Files\Projects\HISKY\SpeckleDenoising\MyContribution\HiskyData\';

% % path = 'D:\Files\Projects\HISKY\SpeckleDenoising\MyContribution\BayesianNLM\'
% % 
% % file = dir(fullfile(path,'*.png')); % (*.dat)
% % 
% % fileNames = {file.name}';
% % 
% % numFiles = size(fileNames,1);
% % 
% % for i = 1:1
% %     singleImgName = strcat(path, fileNames(i));
% % %     fid = fopen(singleImgName{1});
% % %     tline = fread(fid, [512, 512], 'int16');
% % %     R = tline';
% % %     R(R<0) = 0; 
% % %     mask = logical(R);
% % %     R = uint8(R);
% % %     f = @(X) imadjust(X,[],[],1);
% % %     img = roifilt2(R, mask, f);
% % %     figure
% % %     imshow(img,[0, 150])
% %     img = imread(singleImgName{1});
% %     figure
% %     imshow(img)
% % end

img = imread('Image_1 copy.bmp')
[m, n, z] = size(img)
img = rgb2gray(img);
img = imresize(img, [512 512])
blockSize = 5; % size of the block
windowSize = 12; % size of the search window
gapBwnBlock = 2; % gap between the search block (in order to solve computational burden)
h = 8; % filtering parameter controlling the decay of the exponential function

img = ImgNormalize(img);
processedImg = BayesianNLM(img, blockSize, windowSize, gapBwnBlock, h)


figure
subplot 121
imshow(img)
title('Origin Image')
subplot 122
imshow(processedImg)
title('Despecked Image')
% subplot 133
% delta = ~logical(img - processedImg);
% imshow(double(delta))
% title('Subtraction Image')

imwrite(imresize(processedImg, [m n]), 'despeckledImage.png')